% this is a version of the GPR-NN code available from J. Phys. Chem. A 127, 7823 (2023) 
% which has been modified for Nb and NbSi alloy data using in this work. Some parts of the original code are therefore not used in this project. 
% This code is not meant as an end-user-directed distribution. 
% For any questions please contact Sergei Manzhos

function a = playNNviaHDMRGPR(rrmax, length_parameter, lognoise, ifoutliers)
% This is the main function implementing the method
% output is a vector containing [trainRmse testRmse]
% input parameters are optional, there are defaults preset below
% corresponding to optimal hyperparameters found in a scan with 100
% different train-test splits
tic
format compact
%format long
global gprMdl f
global D d Nparams Nsets coordsets widths 
polorder = 1 

% default parameters
if nargin<1,
    rrmax = 0    % number of added redundant coordinates
end;
if nargin<2,
    length_parameter = log(2) % NB: length_parameter enters as as exp( .../(2*exp(l)^2) ) in the kernel function
end;
if nargin<3,
    lognoise = -6.5   % regularization or noise parameter
end;
if nargin<4,
    ifoutliers = 0   % 0 means removing outliers
end;
Sigma0 = 10^lognoise;

ifnormalize = 0               % if 0 then rescaling to [0,1] if 1 then normalizing

% select the dataset to read. First columns is the target, the rest are features 
% is the target 

x = dlmread('Nb.dat');           length_parameter = log(20), lognoise = -6
%x = dlmread('NbI-Nb5Si3.dat');   length_parameter = log(3), lognoise = -5
%x = dlmread('NbII-Nb5Si3.dat');  length_parameter = log(0.5), lognoise = -5%%
%x = dlmread('SiI-Nb5Si3.dat');   length_parameter = log(0.5), lognoise = -3
%x = dlmread('SiII-Nb5Si3.dat'); length_parameter = log(1.5), lognoise = -4

if 0, % if fitting all data together; also have this on when plotting histograms in "if" blocks below
    x = [dlmread('Nb.dat'); dlmread('NbI-Nb5Si3.dat'); dlmread('NbII-Nb5Si3.dat'); dlmread('SiI-Nb5Si3.dat');  dlmread('SiII-Nb5Si3.dat')];
    length_parameter = log(0.1), lognoise = -2.5
    rrmax = 0
end;    

[Npts D] = size(x); 
%rng(5,"twister"); - this may be used to fix a random seed for train-test
%split for particular comparisons. We ran 100 splits for Table 3
if ~ifoutliers,
    ix = [1:Npts]'.*(x(:,36)<10);  % remove outliers
    ix = nonzeros(ix);
    x = x(ix,:); % if ~ifoutliers,
    message = 'removing outliers'
else
    message = 'keeping any outliers'
end;
%for i=1:40, subplot(5,8,i), hist(x(:,i+1),20), end;


V = x(:,1);        
x = x(:,2:end);
% D-reduction by feature importance
if 0,
   featimp = dlmread('feature_importance_SiII.dat');
   featimp = mean(featimp,2);
   [dummy impix] = sort(featimp, 'descend');
   x = x(:,impix(1:30));
   message = 'reduced dimensionality by feature importance'
end;

[Npts D] = size(x)
for i=1:D,
    x(:,i) = rescale(x(:,i));
end;
if ifnormalize, x=normalize(x); end;

% distribition of pairwise distances 
% nos. of points after removing outliers:
% Nb             312
% NbI-Nb5Si3     504
% NbII-Nb5Si3   1540
% SiI-Nb5Si3     840
% SiII-Nb5Si3    518
% total         3714
if 0, % if using this, make sure is [if 1, % if fitting all data together or] is set to 1
    Nbins = 100
    pdisttotal = pdist(x);
    f=figure;
    edgeseven = min(pdisttotal)+(max(pdisttotal)-min(pdisttotal))*[0:Nbins]/Nbins;
    pdistset = pdist(x(1:312,:)); 
    [N,edges] = histcounts(pdistset,edgeseven); 
    plot(edges(1:end-1),N,'b')
    hold on
    pdistset = pdist(x(312+1:312+504,:));
    [N,edges] = histcounts(pdistset,edgeseven); 
    plot(edges(1:end-1),N,'r')
    hold on
    pdistset = pdist(x(312+504+1:312+504+1540,:));
    [N,edges] = histcounts(pdistset,edgeseven); 
    plot(edges(1:end-1),N/3,'g')
    hold on
    pdistset = pdist(x(312+504+1540+1:312+504+1540+840,:));
    [N,edges] = histcounts(pdistset,edgeseven); 
    plot(edges(1:end-1),N,'k')
    hold on
    pdistset = pdist(x(312+504+1540+840+1:312+504+1540+840+518,:));
    [N,edges] = histcounts(pdistset,edgeseven); 
    plot(edges(1:end-1),N,'m')
    hold on
    [N,edges] = histcounts(pdisttotal,edgeseven); 
    plot(edges(1:end-1), N/6,'ok')
    hold on
    set(gca,'FontSize',13)
    xlabel('pairwise distance', 'fontsize', 15) 
    ylabel('no. of data points', 'fontsize', 15)
    hold off
end;  % distributions of pairwise distances

if 0, % distribition of energies.  If using this, make sure is [if 1, % if fitting all data together or] is set to 1
    Nbins = 100
    pdisttotal = V;
    f=figure;
    edgeseven = min(pdisttotal)+(max(pdisttotal)-min(pdisttotal))*[0:Nbins]/Nbins;
    pdistset = V(1:312); 
    [N,edges] = histcounts(pdistset,edgeseven); N = smooth(N);
    plot(edges(1:end-1),N,'b')
    hold on
    pdistset = V(312+1:312+504);
    [N,edges] = histcounts(pdistset,edgeseven); N = smooth(N);
    plot(edges(1:end-1),N,'r')
    hold on
    pdistset = V(312+504+1:312+504+1540);
    [N,edges] = histcounts(pdistset,edgeseven); N = smooth(N);
    plot(edges(1:end-1),N,'g')
    hold on
    pdistset = V(312+504+1540+1:312+504+1540+840);
    [N,edges] = histcounts(pdistset,edgeseven); N = smooth(N);
    plot(edges(1:end-1),N,'k')
    hold on
    pdistset = V(312+504+1540+840+1:312+504+1540+840+518);
    [N,edges] = histcounts(pdistset,edgeseven); N = smooth(N);
    plot(edges(1:end-1),N,'m')
    hold on
    [N,edges] = histcounts(pdisttotal,edgeseven); N = smooth(N);
    plot(edges(1:end-1), N,'ok')
    hold on
    set(gca,'FontSize',13)
    xlabel('energy', 'fontsize', 15) 
    ylabel('no. of data points', 'fontsize', 15)
    hold off
end;  % distributions of pairwise distances


if 0, % distribitions of individual features. If using this, make sure is [if 1, % if fitting all data together or] is set to 1
    Nbins = 20
    for i=1:D,
        subplot(5,8,i)
        edgeseven = min(x(:,i))+(max(x(:,i))-min(x(:,i)))*[0:Nbins]/Nbins;
        pdistset = x(1:312,i);
        [N,edges] = histcounts(pdistset,edgeseven); 
        N = smooth(N);
        plot(edges(1:end-1),N/312,'b')
        hold on
        pdistset = x(312+1:312+504,i);
        [N,edges] = histcounts(pdistset,edgeseven); 
        N = smooth(N);
        plot(edges(1:end-1),N/504,'r')
        hold on
        pdistset = x(312+504+1:312+504+1540,i);
        [N,edges] = histcounts(pdistset,edgeseven); 
        N = smooth(N);
        plot(edges(1:end-1),N/1540,'g')
        hold on
        pdistset = x(312+504+1540+1:312+504+1540+840,i);
        [N,edges] = histcounts(pdistset,edgeseven); 
        N = smooth(N);
        plot(edges(1:end-1),N/840,'k')
        hold on
        pdistset = x(312+504+1540+840+1:312+504+1540+840+518,i);
        [N,edges] = histcounts(pdistset,edgeseven); 
        N = smooth(N);
        plot(edges(1:end-1),N/518,'m')
        hold on
        
        set(gca,'FontSize',13)
        xlabel(['x' num2str(i)], 'fontsize', 15) 
        ylabel('distribution', 'fontsize', 15)        
        hold off
    end; % for i=1:D    
end; % distribitions of individual features

rmse_train = [];
rmse_test = [];
DD = [];      
  sobolpts = Sobol(D,rrmax+1);   % Sobol sequence
  sobolpts = sobolpts (2:end,:); % remove the first row of zeros
  
ssmax = 1        % number of pruning cycles. No cycles are used in this project.
for ss=1:ssmax,  % supercycle of pruning component functions
message = ['starting pruning cyle ' num2str(ss)]
    
%adding redundant coordinates - slices
new = [];
for rr = 1:rrmax,     % number of rounds of adding a vector between all pairs
    new = [new x*sobolpts(rr,:)']; % normalization below will take care of coefficients
end;
x = [x new];
message = 'expanded dimensionality'
[Npts D] = size(x)   % D from now on is the dimension of the redundant coordinates
for i=1:D,
    x(:,i) = rescale(x(:,i));
end;
if ifnormalize, x=normalize(x); end;

% corrplot(x)
Nfit = floor(Npts*0.8)
Ntest = Npts-Nfit
Ntest = min(Ntest,Npts-Nfit) % or use all remaining points is less than Ntest remain

d = 1   % order of HDMR - it is always 1 in this method

Nsets = nchoosek(D,d)
coordsets = nchoosek([1:D],d);

% inital hyperparameters
SigmaF0 = Sigma0;
widths = length_parameter*ones(1,Nsets);
kparams0 = [widths ]; 
Nparams = max(size(kparams0));
order = randperm(max(size(V)));

% if scaling/normalizing also the added coodinates - not really needed
% for i=1:D,
%     x(:,i) = rescale(x(:,i));
% end;
% if ifnormalize, x=normalize(x); end;

% Build a GPR model
gprMdl = fitrgp(x(order(1:Nfit),:),V(order(1:Nfit)),'KernelFunction','kfcnAAfit', ...  %'OptimizeHyperparameters','auto','HyperparameterOptimizationOptions', struct('MaxObjectiveEvaluations',60,'Optimizer','bayesopt'), ...   
    'FitMethod','none','ConstantSigma',false, 'KernelParameters',kparams0,'Sigma',Sigma0, 'SigmaLowerBound', 1e-7, ...
    'Standardize',0, 'Optimizer','fminsearch');
kparams0 = gprMdl.KernelInformation.KernelParameters;
Sigma0 = gprMdl.Sigma
message = 'fitted'
lengths = exp(kparams0)';

if 1,  % this needs to be enabled if pruning is on
    % testing component functions shapes and amplitudes
    widths = kparams0;
    K = kfcnAAfit(x(order(1:Nfit),:),x(order(1:Nfit),:),kparams0);
    c = inv(K+eye(Nfit)*SigmaF0)*V(order(1:Nfit));
    ybreakdown = 0;
    for i=1:Nsets,
        Kstari = kfcnAAbreakdown(x(order(1:Nfit),:),x(order(1:Nfit),:),kparams0,i);
        fcomponent{i} = Kstari*c;
        ybreakdown = ybreakdown+fcomponent{i};
        varfcomponent(i) = var(fcomponent{i});
        meani(i) = mean(fcomponent{i});
    end;
end;

y = predict(gprMdl,x(order(1:Nfit+Ntest),:)); 
message = 'predicted train and test sets'

if 1*(ss==ssmax), % enable this to predict and save the entire dataset
    % predict in batches of bs points to save RAM
    bs = 10000;
    message = 'predicting the entire dataset'
    message = ['batch size: ' num2str(bs)]
    yall = [];
    for i=1:floor(Npts/bs)+1,
        yall = [yall; predict(gprMdl,x((i-1)*bs+1:min(Npts,(i-1)*bs+bs),:) )];
        message = ['predicted batch ' num2str(i)]
    end;
    message = 'predicted the entire dataset'
    rmse_all = sqrt(mean((yall-V).^2))
   
    % saving the predicted values on the entire dataset as a column vector
    % in the same order as the original data
    %dlmwrite(['predicted' num2str(Nfit) 'pts' num2str(D) 'terms.dat'], yall, 'delimiter','\t', 'precision', '%15.8f');
end; % if saving the predicted values

try close(f), end
f=figure; 
f.Position=[100 100 420 400]; 
%subplot(1,2,1)
plot(V(order(Nfit+1:Nfit+Ntest)),y(Nfit+1:Nfit+Ntest),'.r',V(order(1:Nfit)),y(1:Nfit),'.b')   

% NB y is already ordered same as x coming out of predict call so no need to use order for y here
Rtest = corrcoef(V(order(Nfit+1:Nfit+Ntest)),y(Nfit+1:Nfit+Ntest));
Rtest = Rtest(1,2)
Rtrain = corrcoef(V(order(1:Nfit)),y(1:Nfit));
Rtrain = Rtrain(1,2)
set(gca,'FontSize',15)
%title(['  R_{train}=' num2str(Rtrain,'%.3f') ', R_{test}=' num2str(Rtest,'%.3f')],'fontsize', 10)
xlabel('exact','fontsize', 17) 
ylabel('model','fontsize', 17)

rmse_train = [rmse_train; sqrt( mean((V(order(1:Nfit))-y(1:Nfit)).^2) )];
rmse_test = [rmse_test; sqrt( mean((V(order(Nfit+1:Nfit+Ntest))-y(Nfit+1:Nfit+Ntest)).^2) )];
DD = [DD; D];
D_trainRMSE_testRMSE = [DD rmse_train rmse_test]  

% rmse for train and test points with gaps below 2 eV
Vtrain = V(order(1:Nfit));
ytrain = y(1:Nfit);
indtrain2eV = find(Vtrain<2.0);
rmse_train_under2eV = sqrt( mean((Vtrain(indtrain2eV)-ytrain(indtrain2eV)).^2) )
Vtest = V(order(Nfit+1:Nfit+Ntest));
ytest = y(Nfit+1:Nfit+Ntest);
indtest2eV = find(Vtest<2.0);
rmse_test_under2eV = sqrt( mean((Vtest(indtest2eV)-ytest(indtest2eV)).^2) )

%subplot(1,2,2)
%bar(sqrt(varfcomponent))
%set(gca,'FontSize',13)
%title('importance of f_i(x_i)')
%xlabel('feature','fontsize', 15) 
%ylabel('magnitude','fontsize', 15)
try
    fimp = dlmread('feature_importance.dat');
    fimp = [fimp sqrt(varfcomponent)'];
    dlmwrite('feature_importance.dat', fimp, 'delimiter', '\t', 'precision', '%11.5f');
catch
    dlmwrite('feature_importance.dat', sqrt(varfcomponent)', 'precision', '%11.5f');
end;

[dummy orderoffi] = sort(varfcomponent, 'descend');
% plot largest component functions
f = figure; newplot; f.Position=[100 100 2200 850];  
if d==1,
for l=1:min(40,Nsets),
    subplot(5,8,l)
    xf = x(order(1:Nfit),orderoffi(l));
    yf = fcomponent{orderoffi(l)}-mean(fcomponent{orderoffi(l)});
    [dummy orderxf] = sort(xf, 'ascend');
    plot(xf(orderxf), yf(orderxf))
    set(gca,'FontSize',13)
    xlabel(['x' num2str(orderoffi(l))])
    ylabel('f_i(x_i)')
end;
end;
%saveas(f,'fig.png')

ssx = [];
ss
for ssd = 1:D-50,   % XX in D-XX is how many component functions to throw out in each cycle
    ssx = [ssx x(:,orderoffi(ssd))];
end;    
x = ssx;
rrmax = 0;
clear varfcomponent meani fcomponent
end; %supercycle of pruning component functions 

toc 
a = [rmse_train rmse_test rmse_all Rtrain Rtest]; % the return values of the main function 

